user_message = 'User'
admin_message = 'Admin'

catalog = '🛍 Catalog'
balance = '💰 Balance'
cart = '🛒 Basket'
delivery_status = '🚚 Order status'

settings = '⚙️ Directory setup'
orders = '🚚 Orders'
questions = '❓ Questions'
